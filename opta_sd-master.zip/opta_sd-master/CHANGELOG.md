# CHANGELOG

## 1.1.1 - 2 June 2018

### Changed
- Update dependencies due to potential security vulnerability in nokogiri gem

## 1.1 - ( Master ) - 6 May 2017

### Add
- Add Venues

### Changed
- Refactor all parameters methods in Core class and `config/parameters.yml`
- Update Matches `time_range` format

## 1.0 ( First Release ) - 3 Feb 2017

### ADD
- Initial release
