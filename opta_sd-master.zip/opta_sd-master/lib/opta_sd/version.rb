module OptaSD
  VERSION = '1.1.1'.freeze
end
